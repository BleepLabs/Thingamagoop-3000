#include "AudioStream.h"
#include "spi_interrupt.h"

class AudioEffectExtVariableDelay : 
public AudioStream
{
public:
  AudioEffectExtVariableDelay(void): 
  AudioStream(1,inputQueueArray) { 
  }

  void begin( int16_t *dly_main_t, int16_t *dly_temp_t,int32_t max_len,int32_t dly_len, int16_t lerp, int16_t dly_res_div_d);
  void read( int16_t *source_bank, int16_t *dest_bank,uint32_t loc,uint16_t len);
  void write( int16_t *source_bank, int16_t *dest_bank,uint32_t loc,uint16_t len);
  int32_t length(int32_t dly_len);
    int32_t ttiimmee(void);
    void res(int16_t dly_res_div_d){
      dly_res_div= dly_res_div_d;
    }

  virtual void update(void);
  
private:
    uint32_t dlyd,dlyt;    
  int32_t max_dly_len;

  audio_block_t *inputQueueArray[1];
   int16_t *dly_main;
   int16_t *dly_temp;
  int32_t delay_length,desired_delay_length;
  int32_t temp_write_head,temp_read_head;

  int32_t read_head,write_head,read_offset,p_write_head;
  int16_t lerp_len;
  int32_t temp_head;
  uint16_t dly_temp_len=2;
  int16_t tick, tock,dly_res_div;

};

