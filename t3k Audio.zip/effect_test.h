#ifndef effect_test_h_
#define effect_test_h_

#include "AudioStream.h"
#include "utility/dspinst.h"

class AudioEffectTest : public AudioStream
{
public:
  AudioEffectTest() : AudioStream(0, NULL) { }


  virtual void update(void);

  int16_t r(){
    return read1;

  }
 


private:
  int16_t read1;


};

#endif