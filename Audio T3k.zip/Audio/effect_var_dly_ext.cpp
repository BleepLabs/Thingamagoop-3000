#include "effect_var_dly_ext.h"
#include "arm_math.h"


#define SPIRAM_MOSI_PIN  7
#define SPIRAM_MISO_PIN  12
#define SPIRAM_SCK_PIN   14

#define SPIRAM_CS_PIN    6

#define MEMBOARD_CS0_PIN 2
#define MEMBOARD_CS1_PIN 3
#define MEMBOARD_CS2_PIN 4

void AudioEffectExtVariableDelay::begin( int16_t *dly_main_t, int16_t *dly_temp_t,int32_t max_len,int32_t dly_len, int16_t lerp,int16_t dly_res_div_d)
{
  uint32_t memsize = 65536;
  max_dly_len = memsize;
  delay_length= dly_len;
  desired_delay_length = dly_len;

  if (desired_delay_length > max_dly_len) {
    desired_delay_length = max_dly_len;
  }

  dly_main = dly_main_t;
  dly_temp = dly_temp_t;

  write_head = 0;

  lerp_len = lerp;
  dly_res_div=dly_res_div_d;

 // activemask = 0;
 // head_offset = 0;
 // memory_type = AUDIO_MEMORY_23LC1024;


    pinMode(SPIRAM_CS_PIN, OUTPUT);
    digitalWriteFast(SPIRAM_CS_PIN, HIGH);
  

  SPI.setMOSI(SPIRAM_MOSI_PIN);
  SPI.setMISO(SPIRAM_MISO_PIN);
  SPI.setSCK(SPIRAM_SCK_PIN);

  SPI.begin();
 // zero(0, memory_length);


}

#define SPISETTING SPISettings(24000000, MSBFIRST, SPI_MODE0)

int32_t AudioEffectExtVariableDelay::ttiimmee(void)
{
  return dlyd;
}


int32_t AudioEffectExtVariableDelay::length(int32_t dly_len)
{
  desired_delay_length = dly_len;

  if (desired_delay_length > max_dly_len) {
    desired_delay_length = max_dly_len;
  }

  return delay_length;

}


void AudioEffectExtVariableDelay::update(void)
{


  audio_block_t *in_block,*out_block;
  short *bp;

  if (dly_main == NULL)return;

  int32_t max_dly_len_m = max_dly_len-1;

  in_block = receiveWritable(0);

  out_block = allocate();
  if (!out_block) {};

  if (in_block) {
    bp = in_block->data;


    for (int i = 0; i < AUDIO_BLOCK_SAMPLES; i++) {




    //  tock++;
    //  if (tock > dly_res_div) {

      tick++;
      if (tick > lerp_len) {
        if (delay_length < desired_delay_length -4) {
          delay_length++;

          dlyd=(micros()-dlyt);
          dlyt=micros();

        }

        if (delay_length > desired_delay_length + 4) {
          delay_length--;
        }
        tick = 0;
      }

  //    Serial.println(delay_length);

      p_write_head=write_head;

        temp_write_head++;
        write_head++;
        tock = 0;

      if (write_head >= max_dly_len_m) {
        uint16_t wtire_len_t = temp_write_head;
        write(dly_temp,dly_main,write_head,wtire_len_t);
        write_head = 0;
        temp_write_head = 0;
      }

      if (temp_write_head >= dly_temp_len) {
        write(dly_temp,dly_main,write_head,dly_temp_len);
        //write_head+=temp_write_head;
        temp_write_head = 0;
      }

      read_head = ((write_head) + delay_length);
      temp_read_head=read_head-read_offset;


      if (read_head >= (max_dly_len_m)) {
        read_head -= (max_dly_len_m);

        read_offset=read_head;
        temp_read_head=read_head-read_offset;

        read(dly_main,dly_temp,read_offset,dly_temp_len);
      }

      if (temp_read_head  >= dly_temp_len) {

        read_offset=read_head;
        temp_read_head=read_head-read_offset;

        read(dly_main,dly_temp,read_offset,dly_temp_len);
      }
     
   // }

      dly_temp[temp_write_head] = *bp ;
      *bp++ = dly_temp[temp_read_head+100];


    }

    transmit(in_block);
    release(in_block);
    release(out_block);

  }
}


void AudioEffectExtVariableDelay::write( int16_t *source_bank, int16_t *dest_bank,uint32_t loc,uint16_t len)
{
//Serial.print("W ");  Serial.println(loc-dly_temp_len);
  for (int i = 0; i < len; ++i)
  {
 //   dest_bank[loc-len+i]=source_bank[i];
  }

    int32_t addr=loc-len;
    addr *= 2;
    SPI.beginTransaction(SPISETTING);
    digitalWriteFast(SPIRAM_CS_PIN, LOW);
    SPI.transfer16((0x02 << 8) | (addr >> 16));
    SPI.transfer16(addr & 0xFFFF);
    
    for (int i = 0; i < len; ++i)
    {
            SPI.transfer16(source_bank[i]);

    }



    digitalWriteFast(SPIRAM_CS_PIN, HIGH);
    SPI.endTransaction();


}

void AudioEffectExtVariableDelay::read( int16_t *source_bank, int16_t *dest_bank,uint32_t loc,uint16_t len)
{
//Serial.print(" R ");  Serial.println(loc);

  for (int i = 0; i < len; ++i)
  {
  //  dest_bank[i+100]=source_bank[loc+i];
  }
    int32_t addr=loc*2;

  //  addr *= 2;
    SPI.beginTransaction(SPISETTING);
    digitalWriteFast(SPIRAM_CS_PIN, LOW);
    SPI.transfer16((0x03 << 8) | (addr >> 16));
    SPI.transfer16(addr & 0xFFFF);

  //  Serial.print("   ");  Serial.println(addr);
    for (int i = 0; i < len; ++i)
    {
         dest_bank[i+100]=   SPI.transfer16(0);
       //   Serial.println( dest_bank[i+100]);
    }

    digitalWriteFast(SPIRAM_CS_PIN, HIGH);
    SPI.endTransaction();

}

