#include "effect_test.h"




void AudioEffectTest::update(void){

  audio_block_t *blocka,*blockb;
  uint32_t *p, *end, val;


  blocka = allocate();

  if (!blocka) {
   return;
  }

    p = (uint32_t *)(blocka->data);
  end = p + AUDIO_BLOCK_SAMPLES/2;

  //for (int j = 0; j < AUDIO_BLOCK_SAMPLES; j++) {
   //      
 //   Serial.println("....");

  //read1 = analogRead(A6);
  
      *p++ = read1;


  transmit(blocka);
  release(blocka);


}

