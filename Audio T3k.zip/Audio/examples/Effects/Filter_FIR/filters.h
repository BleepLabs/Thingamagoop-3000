// Number of coefficients
#define NUM_COEFFS 100
extern short low_pass[];
extern short band_pass[];

